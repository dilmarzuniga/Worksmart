-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 24-06-2012 a las 23:25:56
-- Versión del servidor: 5.1.53
-- Versión de PHP: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `empleos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `curriculum`
--

CREATE TABLE IF NOT EXISTS `curriculum` (
  `id_curriculum` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `nombres` varchar(100) DEFAULT NULL,
  `apellidos` varchar(100) DEFAULT NULL,
  `fecha_nacimiento` varchar(100) DEFAULT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `dui` varchar(20) DEFAULT NULL,
  `nit` varchar(20) DEFAULT NULL,
  `direccion` varchar(250) DEFAULT NULL,
  `celular` varchar(100) DEFAULT NULL,
  `direccion2` varchar(250) DEFAULT NULL,
  `estado_civil` varchar(100) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `pais` varchar(100) DEFAULT NULL,
  `mensaje_personal` varchar(250) DEFAULT NULL,
  `sexo` varchar(100) DEFAULT NULL,
  `estudios_basicos` varchar(100) DEFAULT NULL,
  `bachillerato` varchar(100) DEFAULT NULL,
  `est_superiores` varchar(100) DEFAULT NULL,
  `exp_laboral` varchar(100) DEFAULT NULL,
  `profesion` varchar(100) DEFAULT NULL,
  `ref_personal` varchar(100) DEFAULT NULL,
  `prof_ref` varchar(100) DEFAULT NULL,
  `tel_ref` varchar(100) DEFAULT NULL,
  `mail_ref` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_curriculum`),
  KEY `id_curriculum` (`id_curriculum`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

--
-- Volcar la base de datos para la tabla `curriculum`
--

INSERT INTO `curriculum` (`id_curriculum`, `username`, `nombres`, `apellidos`, `fecha_nacimiento`, `telefono`, `dui`, `nit`, `direccion`, `celular`, `direccion2`, `estado_civil`, `correo`, `pais`, `mensaje_personal`, `sexo`, `estudios_basicos`, `bachillerato`, `est_superiores`, `exp_laboral`, `profesion`, `ref_personal`, `prof_ref`, `tel_ref`, `mail_ref`) VALUES
(48, 'thiz', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(44, 'adrian', 'Henry Adrian', 'Gómez Romero', '14/01/1992', '2551-0000', '01233555', '0506-140192-0900', 'La Cima', '7998-9090', NULL, 'Acompañado', 'adrian@callejon.com', 'El Salvador', 'Hola :D', 'Masculino', 'Kinder Garten BENDIX', 'Instituto Técnico Ricaldone Opcion Informatica', 'Universidad Don Bosco Ing. Informatica', '13 años', 'Programador', 'Andrea Platero', 'Edecan', '2257-7777', 'andrea@gmail.com'),
(45, 'ana', 'Ana', '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(46, 'k', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(36, 'ryuk', 'sanssss', 'no', '23', '22222222', '00000', '00009', 'san salvador', '799900', NULL, '', '', '', 'hoa', '', 'dsdfsf', 'fff', 'ffffws', 'dd', 'vv', 'cc', 'cfccc', 'vv', ''),
(35, 'dani', 'sanss', 'no', '23', '22222222', '00000', '00009', 'san salvador', '799900', '', '', '', '', 'hoa', '', '', '', '', '', '', '', '', '', ''),
(49, 'karla', 'Karla', '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(50, 'teffy', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(51, 'admin', '', 'Guandique', '196703/05', '22882323', '2342234554', '', 'Residencial Los Andes', '', NULL, 'Soltero', 'ricardo.elias@udb.edu.sv', 'EL SALVADOR', 'DF', 'Masculino', 'sr', ' sdf', 'bla bla', 'bastante', 'catedratico', 'bla bla', 'adfv', '23233445', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresas`
--

CREATE TABLE IF NOT EXISTS `empresas` (
  `id_empresa` varchar(11) NOT NULL DEFAULT '',
  `nombre` varchar(200) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `persona_contacto` varchar(200) DEFAULT NULL,
  `direccion` varchar(500) DEFAULT NULL,
  `departamento` varchar(500) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `telefono` varchar(100) DEFAULT NULL,
  `fax` varchar(20) DEFAULT NULL,
  `tipo` varchar(200) DEFAULT NULL,
  `descripcion` varchar(500) DEFAULT NULL,
  `usrnivel` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_empresa`),
  UNIQUE KEY `id_empresa_2` (`id_empresa`),
  UNIQUE KEY `id_empresa_3` (`id_empresa`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcar la base de datos para la tabla `empresas`
--

INSERT INTO `empresas` (`id_empresa`, `nombre`, `password`, `persona_contacto`, `direccion`, `departamento`, `email`, `telefono`, `fax`, `tipo`, `descripcion`, `usrnivel`) VALUES
('Apple', 'Apple Store', 'A$TGaXsEb6fO6', 'Jose', 'Centro Comercial Galerias Escalon', 'San Salvador', 'appstore.es@apple.com', '22349089', '0', 'Portatiles', 'Tienda de dispositivos electronicos', 2),
('bic', 'BIC', 'b$tnAtpjuDJAE', 'Jose', 'Los Abetos', 'Ahuachapán', 'info@bic.com', '2234-2134', '2248-2189', 'lapices y lapiceros', 'utiles escolares', 2),
('CAESS', 'Compañia de Alumbrado Eléctrico de San Salvador', 'C$OeZ.GId4N5I', 'Jose', 'San Salvador', 'San Salvador', 'caess@aeses.com', '22342134', '0', 'Alumbrado Eléctrico', '', 2),
('Sony', 'SONY', 'S$BVVYBqfZQLE', 'Adrian', 'San Salvador', 'San Salvador', 'sony@service.com', '22342134', '22482189', 'Sociedad Anónima', 'Tienda de dispositivos electronicos', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes`
--

CREATE TABLE IF NOT EXISTS `mensajes` (
  `id_mensaje` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `mensaje` varchar(500) DEFAULT NULL,
  `leido` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_mensaje`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Volcar la base de datos para la tabla `mensajes`
--

INSERT INTO `mensajes` (`id_mensaje`, `id_user`, `mensaje`, `leido`) VALUES
(16, 1, 'borrar la cuenta', 0),
(14, 35, 'borrar la cuenta', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `plazas`
--

CREATE TABLE IF NOT EXISTS `plazas` (
  `id_empleo` int(11) NOT NULL AUTO_INCREMENT,
  `id_empresa` varchar(11) DEFAULT NULL,
  `descripcion` varchar(500) DEFAULT NULL,
  `salario` varchar(100) DEFAULT NULL,
  `nomb_empleo` varchar(100) NOT NULL,
  `requisitos_empleo` varchar(500) DEFAULT NULL,
  `tipo_contrato` varchar(200) DEFAULT NULL,
  `genero` varchar(30) DEFAULT NULL,
  `Edad_rango` varchar(15) DEFAULT NULL,
  `vehiculo` varchar(50) DEFAULT NULL,
  `depto_plaza` varchar(50) DEFAULT NULL,
  `Categoria` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id_empleo`),
  KEY `id_empleo` (`id_empleo`),
  KEY `id_empresa` (`id_empresa`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Volcar la base de datos para la tabla `plazas`
--

INSERT INTO `plazas` (`id_empleo`, `id_empresa`, `descripcion`, `salario`, `nomb_empleo`, `requisitos_empleo`, `tipo_contrato`, `genero`, `Edad_rango`, `vehiculo`, `depto_plaza`, `Categoria`) VALUES
(1, 'Apple', 'Administración de balances                                        ', '$800', 'Auxiliar contable', '  Excelente presentación    ', '', '', '', '', 'Cualquiera', 'Informatica'),
(10, 'bic', '', '$250', 'Bartender', 'Sin problemas de horario', 'Nocturno', 'Masculino', '18-25', 'Indiferente', 'Usulutan', 'servicio_cliente'),
(11, 'bic', 'kjojkjmkjkjwe', '200', 'Aeromosa', 'dsfsdfasdfasdfa', 'Nocturno', 'Femenino', 'Rango separado ', 'Indiferente', 'San Salvador', 'turismo'),
(12, 'bic', 'Digitación de Datos', '$100', 'Secretaria', ' Excelente presentación, Conocimientos de Office 2003', 'Sabatino', 'Femenino', '18-30', 'Requerido', 'Santa Ana', 'admin_oficina'),
(13, 'Apple', 'Edecan para fin de semana por un mes       ', '$500', 'Edecan', 'Buen Cuerpo', 'Temporal', 'Femenino', '21-25', 'Indiferente', 'San Salvador', 'otros'),
(14, NULL, 'qweqweqeqw', '$500', 'alaskdlaskd', 'adahjdhqjehwqjeqwasdasd', 'qeqweasdf', 'Femenino', '10-20', 'Requerido', 'Santa Ana', NULL),
(15, NULL, 'sfaqeqeqw', '500', 'qeqwe', 'qweqweqwe', 'qeqweqwe', 'Femenino', '10-80', 'Requerido', 'San Salvador', NULL),
(16, 'Apple', 'Repartidor de productos                    ', '350', 'Repartidor', ' Licencia de Conducir tipo LIVIANA    ', 'Tiempo Completo', 'Indiferente', '25-30', 'no', 'chalatenango', 'otros'),
(17, NULL, 'adsqeqewrrw', '600', 'htrtrhsdfsd', 'sfsdfasf', 'completo', 'femenino', '18-20', 'SI', 'sonsonate', 'servicio al cliente'),
(19, NULL, 'Administración de balances                    ', '$500', 'Auxiliar contable', ' Excelente presentación  ', 'Medio Tiempo', 'Indiferente', '', '', 'Cualquiera', 'Informatica'),
(20, NULL, 'Administración de balances                    ', '$500', 'Auxiliar contable', ' Excelente presentación  ', '', '', '', '', 'Cualquiera', 'Informatica'),
(21, NULL, 'Administración de balances                    ', '$100', 'Auxiliar contable', ' Excelente presentación  ', '', '', '', '', 'Cualquiera', 'Informatica'),
(22, NULL, 'Administración de balances                    ', '$100', 'Auxiliar contable', ' Excelente presentación  ', '', '', '', '', 'Cualquiera', 'Informatica'),
(23, NULL, 'Administración de balances                    ', '$100', 'Auxiliar contable', ' Excelente presentación  ', '', '', '', '', 'Cualquiera', 'Informatica'),
(24, NULL, 'ss', '$0', 'Prueba', ' ss', 'Medio Tiempo', 'Femenino', 'indiferente', 'Indiferente', 'Ahuachapan', 'Administración Oficinas'),
(25, '', 'ss', '222', 'Prueba 1', ' sss', 'Medio Tiempo', 'Femenino', 'no importa edad', 'Indiferente', 'Ahuachapan', 'Administración Oficinas'),
(26, '', 'ss', 'ss', 'ss', ' ss', 'Medio Tiempo', 'Femenino', '', 'Indiferente', 'Ahuachapan', 'Administración Oficinas'),
(28, 'CAESS', 'Reparacion de daños en hogares                                        ', '555', 'Electricista', ' Tecnico Electronica    ', 'Medio Tiempo', 'Indiferente', '20 - 25 años', 'Requerido', 'Cabañas', 'informatica');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes`
--

CREATE TABLE IF NOT EXISTS `solicitudes` (
  `id_solicitud` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(10) DEFAULT NULL,
  `id_empleo` int(100) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`id_solicitud`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `solicitudes`
--

INSERT INTO `solicitudes` (`id_solicitud`, `id_user`, `id_empleo`, `fecha`) VALUES
(1, 36, 1, NULL),
(2, 36, 24, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `id_user` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(500) DEFAULT NULL,
  `nombre` varchar(100) NOT NULL,
  `password` varchar(45) NOT NULL,
  `nivel` int(11) NOT NULL,
  PRIMARY KEY (`id_user`),
  KEY `id_user` (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Volcar la base de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_user`, `username`, `nombre`, `password`, `nivel`) VALUES
(1, 'Lam', 'Néstor Lam', 'L$ycdbrWULcbA', 1),
(3, 'Ruso', 'David Alemán', 'R$kE9B2fn9Ew2', 1),
(4, 'Rake', 'Raquel Sibrian', 'R$vQevJuOWKcU', 1),
(6, 'Apple', 'Apple Store', 'A$TGaXsEb6fO6', 2),
(17, 'Sony', 'SONY', 'S$BVVYBqfZQLE', 2),
(18, 'tommy', 'Tommy', 't$RaubMK96diA', 3),
(20, 'Ale', 'Alejandra Meléndez', 'A$MAfUWUqzLKU', 1),
(21, 'Rodrigo', 'Rodrigo Rodriguez', 'R$kAbrcetcQRI', 1),
(24, 'thiz', 'thiz', 't$UN3SXRQbhWI', 1),
(26, 'CAESS', 'Compañia de Alumbrado Eléctrico de San Salvador', 'C$OeZ.GId4N5I', 2),
(27, 'bic', 'BIC', 'b$tnAtpjuDJAE', 2),
(28, 'jose', 'Jose', 'j$25Cs3EORK22', 3),
(29, 'jose', 'Jose', 'j$25Cs3EORK22', 3),
(30, 'Andrea', 'Andrea', 'A$oB45ccuyzNw', 3),
(34, 'dani', 'Daniel', 'd$hRaco0evKUo', 3),
(35, 'ryuk', 'Ryuk', 'r$hNVCVRZT7fs', 3),
(36, 'adrian', 'adrian', 'a$GmffM.8vYBs', 3),
(37, 'ana', 'ana', 'a$MGbTgIGbS4w', 3),
(38, 'k', 'k', 'k$CTTar.FDrDo', 3),
(40, 'thiz', 'Thiz', 't$UN3SXRQbhWI', 3),
(41, 'karla', 'karla', 'k$mI2U6nKkTtE', 3),
(42, 'teffy', 'Stephanie', 't$rY7XmUGumeY', 3),
(43, 'admin', 'Ricardo Elias Guandique', 'a$jdLmRuLn5oc', 3);
